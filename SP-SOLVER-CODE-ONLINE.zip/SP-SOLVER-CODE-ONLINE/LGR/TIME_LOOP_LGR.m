%---------Input parameters--------

% Grid cells in x,y,z for the LGR
DXC = 20;
DYC = 11;
DZC = 20;

% Grid cells in x, y, z for the parent model without the added shale
DX = 33;
DY = 3;
DZ = 10;

% Grid cells in x, y, z for the parent model without the added shale
DX3D = DX;
DY3D = DY;
DZ3D = DZ+20;

% Number of LGR
num=1;

% Time steps
v=[ 3 6 9 12 15 18 21 24 27 30 33 36 30 40 41 42 43 44 45 46 47 48]; 

%---------End of Input parameters--------


onlylast=1;


for j = 1:length(v)
    i = v(j);
formatspec = '[xc,yc,zc,Pc%d,Sc%d,SALTc%d,Uekc%d,Uecc%d,L_ekc%d,sigmac%d,L_ecc%d,POROc,HOSTNUM_C,TEMPc%d,Utec%d] = SP_FUNCTION_LGR(DXC,DYC,DZC,i,onlylast,num,Uekw%d,sigma%d,P%d,L_ek%d,DX3D,DY3D,DZ3D,DX,DY,DZ,x,y,z,Uecw%d,SALT%d,L_ec%d,POROp,SATNUMp,Utew%d,TEMP%d,L_te%d);';
eval(sprintf(formatspec,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i,i));
end


    