
%------------------inputs-------------------------------
% x and y slice of the the well in the LGR
xsec=6;
ysec=7;

% time steps
i = [3 6 9 12 15 18 21 24 27 30 33 36 30 40 41 42 43 44 45 46 47 48];

% location of the sector : a layer
zz=10;

% chang the selected sector for x and y sections
% chang the plot function for x and y axis
% chag the property you want to plot
%----------------end of inputs-------------------------

% x and y 
XAc = zeros(length(xc)-1,1);  %mid of each cell

for cc= 1: length(xc)-1
    XAc(cc) = (xc(cc+1)+xc(cc))/2;
end
 
YAc = zeros(length(yc)-1,1);  %mid of each cell

for cc= 1: length(yc)-1
    YAc(cc) = (yc(cc+1)+yc(cc))/2;
end


figure
% Read the selected variabled across the horizontal section selected
for L = 1:length(i)
     LL = i(L);
     format1 = 'HOR_SEC  = SALTc%d(ysec,:,zz);';% can be modified based on the location of the sector required
      eval(sprintf(format1,LL));
      HOR_SEC  = HOR_SEC(:);
      
      plot (XAc,HOR_SEC); % modified based on x and y
      title('cross section');
      hold on

     legendInfo{L} = ['TS ' num2str(LL)]; 

end


     legend(legendInfo)



 hold off

