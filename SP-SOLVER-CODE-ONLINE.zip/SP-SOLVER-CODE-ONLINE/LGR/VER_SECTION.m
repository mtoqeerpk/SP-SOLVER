%------------------inputs-------------------------------
% x and y slice of the the well in the LGR
xsec=6;
ysec=7;

% time steps
i = [3 6 9 12 15 18 21 24 27 30 33 36 30 40 41 42 43 44 45 46 47 48];

% chag the property you want to plot
%----------------end of inputs-------------------------


ZAc = zeros(length(zc)-1,1);  %mid of each cell

for cc= 1: length(zc)-1
    ZAc(cc) = (zc(cc+1)+zc(cc))/2;
end

figure

% Read the selected variabled across the horizontal section selected

for L = 1:length(i)
     LL = i(L);
     format1 = 'VER_SECc  =SALTc%d(ysec,xsec,:);';
     eval(sprintf(format1,LL));
  
      
      VER_SECc  = VER_SECc(:);
      
      plot (VER_SECc,ZAc);
      title('cross section');
      hold on

     legendInfo{L} = ['TS ' num2str(LL)]; 

end


     legend(legendInfo)



 hold off


