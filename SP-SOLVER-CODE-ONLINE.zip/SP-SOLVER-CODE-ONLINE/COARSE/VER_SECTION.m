%------------------inputs-------------------------------
% x and y slice of the the well in the parent model
xsec=3;
ysec=2;

% time steps
i = [3 6 9 12 15 18 21 24 27 30 33 36 30 40 41 42 43 44 45 46 47 48];

% chag the property you want to plot
%----------------end of inputs-------------------------

% max z fix. acn be modified based on the grid considered
ZA = zeros(length(z)-1,1);  

for cc= 1: length(z)-1
    ZA(cc) = (z(cc+1)+z(cc))/2;
end

figure

% Read the selected variabled across the vertical section selected

for L = 1:length(i)
     LL = i(L);
     format1 = 'VER_SEC  = 1000*Uekw%d(ysec,xsec,:);';
      eval(sprintf(format1,LL));
      
      VER_SEC  = VER_SEC(:);
      
      plot (VER_SEC,ZA);
      title('cross section');
      hold on

     legendInfo{L} = ['TS ' num2str(LL)]; 

end


     legend(legendInfo)



 hold off


