% INPUT PARAMETERS
v = [3 6 9 12 15 18 21 24 27 30 33 36 30 40 41 42 43 44 45 46 47 48 ];% time steps
DX = 33; DY = 3; DZ = 10;% grid size


for j = 1:length(v)
    i = v(j);
formatspec = '[Uek%d,P%d,S%d,SALT%d,x,y,z,Uec%d,DX3D,DY3D,DZ3D,sigma%d,L_ec%d,L_ek%d,POROp,SATNUMp,Ute%d,TEMP%d,L_te%d] = SP_FUNCTION_COARSE(DX,DY,DZ,i);';
eval(sprintf(formatspec,i,i,i,i,i,i,i,i,i,i,i));
end
